let player;
let foods = [];
let enemies = [];
let zoom = 1;
let playerImg;
let bgImg;
let bgMusic;
let gameOver = false;

function preload() {
  playerImg = loadImage('m1.png'); // 加载玩家图片
  bgImg = loadImage('b1.png'); // 加载背景图片
  // bgMusic = loadSound('bm1.mp3'); // 加载背景音乐
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  player = new Player(random(width), random(height), 30, playerImg);

  foods = [];
  enemies = [];
  
  
  for (let i = 0; i < 50; i++) {
    foods.push(new Food(random(width * 2) - width, random(height * 2) - height));
  }

  for (let i = 0; i < 5; i++) {
    enemies.push(new Enemy(random(width * 2) - width, random(height * 2) - height, random(40, 80)));
  }

  // 设置音乐循环播放
  // bgMusic.setLoop(true);
  // bgMusic.play();
}

function draw() {
  if (gameOver) { 
    showGameOverScreen();
    return;
  } 
  
  // background(0);
   background(bgImg); // 设置背景图片

  translate(width / 2, height / 2);
  // let newZoom = constrain(30 / player.r, 0.5, 2);
  // zoom = lerp(zoom, newZoom, 0.1);
  // scale(zoom);
  translate(-player.pos.x, -player.pos.y);

  for (let food of foods) {
    food.show();
  }

  for (let enemy of enemies) {
    enemy.show();
    enemy.update();
  }

  player.update();
  player.show();

  // 吞食食物
  for (let i = foods.length - 1; i >= 0; i--) {
    if (player.eats(foods[i])) {
      foods.splice(i, 1);
      foods.push(new Food(random(width * 2) - width, random(height * 2) - height));
    }
  }

  // 处理敌人
  for (let i = enemies.length - 1; i >= 0; i--) {
    if (player.eats(enemies[i])) {
      player.r += enemies[i].r * 0.2;
      enemies.splice(i, 1);  // 玩家吃掉敌人，删除
    } else if (enemies[i].eats(player)) {
      gameOver = true;
      return;
       // 敌人吃掉玩家，game over
    }
  }
}

// function applyFoodEffect( food ) {
//   if ( food.type === "normal") {
//     player.mark += 
//   }
// }


//游戏结束屏幕
function showGameOverScreen() {
  background(0);
  fill(255, 0, 0);
  textSize(50);
  textAlign(CENTER, CENTER);
  text("Game Over", width / 2, height / 2 - 50);
  textSize(30);
  text("Press 'R' to Restart", width / 2, height / 2 + 20);
}

//按R重新开始
function keyPressed() {
  if (key === 'R' || key === 'r') {
    restartGame();
  }
}


//重新开始
function restartGame() {
  gameOver = false;
  setup();
}



class Player {
  // 创建玩家
  constructor(x, y, r, img) {
    this.pos = createVector(x, y);
    this.r = r;
    this.mark = 0;
    this.img = img;
  }
  
  // 通过鼠标移动，每次朝鼠标方向移动一点
  update() {
    let mouseVec = createVector(mouseX - width / 2, mouseY - height / 2);
    mouseVec.setMag(3.5); //更改自机速度，与敌人最大速度相同
    this.pos.add(mouseVec);
  }
  
  // 绘制玩家角色
  show() {
    // fill(0, 255, 0);
    // ellipse(this.pos.x, this.pos.y, this.r * 2);
    
    
    let imgWidth = this.r * 2;
    let imgHeight = this.r * 2;
    image(this.img, this.pos.x - this.r, this.pos.y - this.r, imgWidth, imgHeight);
    
    
  }
  
  // 碰到后吃掉
  eats(other) {
    let d = dist(this.pos.x, this.pos.y, other.pos.x, other.pos.y);
    if (d < this.r + other.r && this.r > other.r) { //添加判断敌人和玩家谁大
      this.r += other.r * 0.1;
      return true;
    }
    return false;
  }
}


class Food {
  constructor(x, y, type) {
    this.pos = createVector(x, y);
    this.r = random(5, 15);
    this.type = random(["normal", "trap", "power"]);
  }

  show() {
    if (this.type === "normal") fill(200, 200, 0);  // 黄
    if (this.type === "trap") fill(255, 0, 0);  // 红
    if (this.type === "power") fill(0, 0, 255);  // 蓝
    ellipse(this.pos.x, this.pos.y, this.r * 2);
  }
}

class Enemy {
  // 创建敌人，设置位置pos，大小r和速度
  constructor(x, y, r, speed) {
    this.pos = createVector(x, y);
    this.r = r;
    this.speed = random(0.5, 3); //敌人随机速度 最大速度与玩家速度相同
  }

  update() {
    let dir = p5.Vector.sub(player.pos, this.pos);
    
    //比玩家大的追击 小的逃跑
    if (this.r > player.r) {
      dir.setMag(this.speed);
      this.pos.add(dir);
    } else {
      dir.setMag(-this.speed);
      this.pos.add(dir);
    }
  }

  // 用红色ellipse() 绘制敌人
  show() {
    fill(255, 50, 50);
    ellipse(this.pos.x, this.pos.y, this.r * 2);
  }

  // 检查敌人能否吞食玩家
  eats(other) {
    let d = dist(this.pos.x, this.pos.y, other.pos.x, other.pos.y);
    return d < this.r + other.r;
  }
}  