let player;
let foods = [];
let enemies = [];
let zoom = 1;

function setup() {
  createCanvas(windowWidth, windowHeight);
  player = new Player(random(width), random(height), 30);
  
  for (let i = 0; i < 50; i++) {
    foods.push(new Food(random(width * 2) - width, random(height * 2) - height));
  }
  
  for (let i = 0; i < 5; i++) {
    enemies.push(new Enemy(random(width * 2) - width, random(height * 2) - height, random(40, 80)));
  }
}

function draw() {
  background(10);
  
  translate(width / 2, height / 2);
  let newZoom = 30 / player.r;
  zoom = lerp(zoom, newZoom, 0.1);
  scale(zoom);
  translate(-player.pos.x, -player.pos.y);
  
  for (let food of foods) {
    food.show();
  }
  
  for (let enemy of enemies) {
    enemy.show();
    enemy.update();
  }
  
  player.update();
  player.show();
  
  // 吞食食物
  for (let i = foods.length - 1; i >= 0; i--) {
    if (player.eats(foods[i])) {
      foods.splice(i, 1);
      foods.push(new Food(random(width * 2) - width, random(height * 2) - height));
    }
  }
  
  // 处理敌人
  for (let i = enemies.length - 1; i >= 0; i--) {
    if (player.eats(enemies[i])) {
      player.r += enemies[i].r * 0.2;
      enemies.splice(i, 1);
    } else if (enemies[i].eats(player)) {
      setup(); // 重新开始游戏
    }
  }
}

class Player {
  constructor(x, y, r) {
    this.pos = createVector(x, y);
    this.r = r;
  }
  
  update() {
    let mouseVec = createVector(mouseX - width / 2, mouseY - height / 2);
    mouseVec.setMag(5);
    this.pos.add(mouseVec);
  }
  
  show() {
    fill(0, 255, 0);
    ellipse(this.pos.x, this.pos.y, this.r * 2);
  }
  
  eats(other) {
    let d = dist(this.pos.x, this.pos.y, other.pos.x, other.pos.y);
    if (d < this.r + other.r) {
      this.r += other.r * 0.1;
      return true;
    }
    return false;
  }
}
class Food {
  constructor(x, y) {
    this.pos = createVector(x, y);
    this.r = random(5, 15);
    this.type = random(["normal", "trap", "power"]);
  }
  
  show() {
    if (this.type === "normal") fill(200, 200, 0);
    if (this.type === "trap") fill(255, 0, 0);
    if (this.type === "power") fill(0, 0, 255);
    ellipse(this.pos.x, this.pos.y, this.r * 2);
  }
}

class Enemy {
  constructor(x, y, r) {
    this.pos = createVector(x, y);
    this.r = r;
  }
  
  update() {
    let dir = p5.Vector.sub(player.pos, this.pos);
    dir.setMag(1);
    this.pos.add(dir);
  }
  
  show() {
    fill(255, 50, 50);
    ellipse(this.pos.x, this.pos.y, this.r * 2);
  }
  
  eats(other) {
    let d = dist(this.pos.x, this.pos.y, other.pos.x, other.pos.y);
    return d < this.r + other.r;
  }
}